<?php

namespace FS\BunnyIntegration\XF\Pub\Controller;

use XF\Mvc\ParameterBag;

class Attachment extends XFCP_Attachment
{
    public function actionUpload()
    {
        $isBunnyUpload = $this->filter('isBunnyUpload', 'str');

        if ($isBunnyUpload == "1") {

            var_dump($isBunnyUpload);
            $type = $this->filter('type', 'str');
            $handler = $this->getAttachmentRepo()->getAttachmentHandler($type);
            if (!$handler) {
                return $this->noPermission();
            }

            $context = $this->filter('context', 'array-str');
            if (!$handler->canManageAttachments($context, $error)) {
                return $this->noPermission($error);
            }

            $hash = $this->filter('hash', 'str');
            if (!$hash) {
                return $this->noPermission();
            }

            /** @var \XF\Attachment\Manipulator $manipulator */
            $class = \XF::extendClass('XF\Attachment\Manipulator');
            $manipulator = new $class($handler, $this->getAttachmentRepo(), $context, $hash);

            if ($this->isPost()) {
                $json = [];

                $delete = $this->filter('delete', 'uint');
                if ($delete) {
                    $manipulator->deleteAttachment($delete);
                    $json['delete'] = $delete;
                } else {
                    $uploadError = null;
                    if ($manipulator->canUpload($uploadError)) {
                        $upload = $this->request->getFile('upload', false, false);
                        if ($upload) {
                            $attachment = $manipulator->insertAttachmentFromUpload($upload, $error);
                            if (!$attachment) {
                                return $this->error($error);
                            }

                            $bunnyService = \xf::app()->service('FS\BunnyIntegration\XF:BunnyServ');

                            $createVideo = $bunnyService->createBunnyVideo("FS Bunny Video_" . time());

                            $attachment->fastUpdate('bunny_vid_id', $createVideo['guid']);

                            $json['attachment'] = [
                                'attachment_id' => $attachment->attachment_id,
                                'filename' => $attachment->filename,
                                'file_size' => $attachment->file_size,
                                'file_size_printable' => \XF::language()->fileSizeFormat($attachment->file_size),
                                'thumbnail_url' => $attachment->thumbnail_url,
                                'width' => $attachment->Data->width,
                                'height' => $attachment->Data->height,
                                'icon' => $attachment->icon,
                                'is_video' => $attachment->is_video,
                                'is_audio' => $attachment->is_audio,
                                'link' => $attachment->direct_url,
                                'type_grouping' => $attachment->type_grouping
                            ];
                            $json['link'] = $json['attachment']['link'];

                            $json = $handler->prepareAttachmentJson($attachment, $context, $json);
                        }
                    } else if ($uploadError) {
                        return $this->error($uploadError);
                    }
                }

                $reply = $this->redirect($this->buildLink('attachments/upload', null, [
                    'type' => $type,
                    'context' => $context,
                    'hash' => $hash
                ]));
                $reply->setJsonParams($json);

                return $reply;
            } else {
                $uploadError = null;
                $canUpload = $manipulator->canUpload($uploadError);

                $viewParams = [
                    'handler' => $handler,
                    'constraints' => $manipulator->getConstraints(),

                    'canUpload' => $canUpload,
                    'uploadError' => $uploadError,
                    'existing' => $manipulator->getExistingAttachments(),
                    'new' => $manipulator->getNewAttachments(),

                    'hash' => $hash,
                    'type' => $type,
                    'context' => $context
                ];
                return $this->view('XF:Attachment\Upload', 'attachment_upload', $viewParams);
            }
        } else {

            return parent::actionUpload();
        }
    }

    // public function bunnyUpload()
    // {
    //     $videoFile = $_FILES['bunny_video'];

    //     $bunnyService = \xf::app()->service('FS\BunnyIntegration\XF:BunnyServ');
    //     $createVideo = $bunnyService->createBunnyVideo("FS Bunny Video_" . time());

    //     $fileDataPath = 'data://BunnyIntegration/';

    //     $videoExtenion = pathinfo($videoFile['name'], PATHINFO_EXTENSION);

    //     $moveVideo = \XF\Util\File::copyFileToAbstractedPath($videoFile['tmp_name'],  $fileDataPath . $createVideo['guid'] . "." . $videoExtenion);


    //     $fileSize = $videoFile['size'];
    //     $convertedSize = $this->convertFileSize($fileSize);

    //     $videoTempParam = [
    //         "videoUrl" => "data/BunnyIntegration/" . $createVideo['guid'] . "." . $videoExtenion,
    //         "videoName" => $videoFile['name'],
    //         "convertedSize" => $convertedSize,
    //         "bunnyVideoName" => $createVideo['guid'] . "." . $videoExtenion,
    //     ];

    //     $videoHTML = \XF::app()->templater()->renderTemplate('public:fs_bunny_uploaded_video_html', $videoTempParam);

    //     $viewParams = [
    //         'status' => $moveVideo ?  true : false,
    //         'bunnyVideoId' => $createVideo ? $createVideo['guid'] : '',
    //         'attachmentVideoHTML' => $videoHTML
    //     ];

    //     $this->setResponseType('json');
    //     $view = $this->view();
    //     $view->setJsonParam('data', $viewParams);
    //     return $view;
    // }
}
