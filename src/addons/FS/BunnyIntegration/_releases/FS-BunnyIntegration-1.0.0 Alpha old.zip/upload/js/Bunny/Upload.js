function _(el) {
  return document.getElementById(el);
}

function uploadFile() {
  var file = _("bunny_video").files[0];

  var formdata = new FormData();

  formdata.append("bunny_video", file);

  var phraseUrl = XF.canonicalizeUrl("index.php?forums/0/upload");

  formdata.append("_xfToken", XF.config.csrf);

  $("#overlay").css("display", "block");

  $.ajax({
    type: "POST",
    url: phraseUrl,
    data: formdata,
    contentType: false,
    processData: false,
    success: function (response) {
      console.log(response);
      $("#response").html(response);
      $('input[name="bunnyVidId"]').val(response.data.bunnyVideoId);
      $("#overlay").css("display", "none");
    },
  });
}
