<?php

namespace FS\BunnyIntegration\XF\Pub\Controller;

class Forum extends XFCP_Forum
{
    protected function setupThreadCreate(\XF\Entity\Forum $forum)
    {
        $visitor = \XF::visitor();
        $options = \XF::options();
        if (!$visitor->hasPermission('fs_bunny', 'allow') || !$options->fs_bi_libraryId || !$options->fs_bi_accessKey) {
            return parent::setupThreadCreate($forum);
        }

        $getvideo = $this->request->getFile('bunny_video', false, false);

        $parent = parent::setupThreadCreate($forum);

        if ($getvideo) {

            $check_ext = $getvideo->isvideo();

            if (!$check_ext) {
                throw $this->exception(
                    $this->notFound(\XF::phrase("fs_bunny_you_can_only_video"))
                );
            } else {

                $parent->setBunnyDataIds($options->fs_bi_libraryId, $this->filter('bunnyVidId', 'str'));
            }
        }

        return $parent;
    }



    public function uploadVideo($sourceFile, $abstractPath)
    {
        try {
            \XF\Util\File::copyFileToAbstractedPath($sourceFile, $abstractPath);
        } catch (\Exception $e) {
            throw $e;
        }
    }

    protected function finalizeThreadCreate(\XF\Service\Thread\Creator $creator)
    {
        $visitor = \XF::visitor();
        $thread = $creator->getThread();

        $visitor = \XF::visitor();
        $options = \XF::options();
        if (!$visitor->hasPermission('fs_bunny', 'allow') || !$options->fs_bi_libraryId || !$options->fs_bi_accessKey) {
            return parent::finalizeThreadCreate($creator);
        }

        $getvideo = $this->request->getFile('bunny_video', false, false);

        if ($getvideo) {

            $videoExtenion = $getvideo->getExtension();

            if ($thread) {

                $post = $thread->FirstPost;

                $bunnyBBCode = "[fsbunny=" . $thread['bunny_lib_id'] . "][/fsbunny]";

                $newMessage = $post->message . " [br]1[/br] " . $bunnyBBCode;

                $post->fastUpdate('message', $newMessage);
            }

            $app = \XF::app();

            $jopParams = [
                'threadId' => $thread->thread_id,
                'libarayId' => $thread['bunny_lib_id'],
                'videoId' => $thread['bunny_vid_id'],
                'bunnyVideo' => $thread['bunny_vid_id'] . "." . $videoExtenion,
            ];

            $jobID = $visitor->user_id . '_bunnyVideo_' . time();

            $app->jobManager()->enqueueUnique($jobID, 'FS\BunnyIntegration:BunnyUpload', $jopParams, false);
            // $app->jobManager()->runUnique($jobID, 120);
        }

        return parent::finalizeThreadCreate($creator);
    }

    public function actionUpload()
    {
        $videoFile = $_FILES['bunny_video'];

        $bunnyService = \xf::app()->service('FS\BunnyIntegration\XF:BunnyServ');
        $createVideo = $bunnyService->createBunnyVideo("FS Bunny Video_" . time());

        $fileDataPath = 'data://BunnyIntegration/';

        // $moveVideo = \XF\Util\File::copyFileToAbstractedPath($sourceFile, $fileDataPath . $createVideo['guid'] . "." . $videoExtenion);

        $videoExtenion = pathinfo($videoFile['name'], PATHINFO_EXTENSION);

        $moveVideo = \XF\Util\File::copyFileToAbstractedPath($videoFile['tmp_name'],  $fileDataPath . $createVideo['guid'] . "." . $videoExtenion);

        // $getvideo = $this->request->getFile('bunny_video', false, false);
        $viewParams = [
            'status' => $moveVideo ?  true : false,
            'bunnyVideoId' => $createVideo ? $createVideo['guid'] : ''
        ];

        $this->setResponseType('json');
        $view = $this->view();
        $view->setJsonParam('data', $viewParams);
        return $view;
    }
}
