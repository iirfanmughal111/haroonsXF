<?php

namespace FS\BunnyIntegration\XF\Service\Thread;

class Creator extends XFCP_Creator
{
    protected $bunny_lib_id;
    protected $bunny_vid_id;

    public function setBunnyDataIds($libraryId, $videoId)
    {
        $this->thread->bunny_lib_id = $libraryId;
        $this->thread->bunny_vid_id = $videoId;
    }
}
