<?php

namespace FS\BunnyIntegration\XF\Pub\Controller;

use XF\Mvc\ParameterBag;

class Thread extends XFCP_Thread
{
    public function actionCheckVideo(ParameterBag $params)
    {
        $thread = \XF::em()->find('XF:Thread', $params->thread_id);

        $libId = $thread['bunny_lib_id'];
        $videoId = $thread['bunny_vid_id'];

        $bunnyAccessKey = \XF::options()->fs_bi_accessKey;

        $curl = curl_init();

        curl_setopt($curl, CURLOPT_URL, "https://video.bunnycdn.com/library/" . $libId . "/videos/" . $videoId);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_HTTPHEADER, [
            'AccessKey: ' . $bunnyAccessKey,
        ]);

        $server_output = curl_exec($curl);

        curl_close($curl);
        $getVideoRes = json_decode($server_output, true);

        $status = (isset($getVideoRes["encodeProgress"]) && $getVideoRes["encodeProgress"] == 100) ? true : false;

        $viewParams = [
            'status' => $status,
            'thread_id' => $params->thread_id
        ];
        $this->setResponseType('json');

        $view = $this->view();
        $view->setJsonParam('data', $viewParams);
        return $view;
    }
}
