<?php

namespace FS\BunnyIntegration\Job;

use XF\Job\AbstractJob;

class BunnyUpload extends AbstractJob
{
    protected $defaultData = [];

    public function run($maxRunTime)
    {
        $s = microtime(true);

        $app = \xf::app();

        $libarayId = $this->data['libarayId'];
        $videoId = $this->data['videoId'];

        $filePath = "https://e-dewan.ams3.cdn.digitaloceanspaces.com" . "/data/BunnyIntegration/" . $this->data['bunnyVideo'];

        // $filePath = \XF::getRootDirectory() . "/data/BunnyIntegration/" . $this->data['bunnyVideo'];

        //  var_dump(file_exists($filePath),$filePath);exit;
        //  if (file_exists($filePath)) {

        $binaryVideo = file_get_contents($filePath);

        $bunnyService = $app->service('FS\BunnyIntegration\XF:BunnyServ');
        $uploadVideoRes = $bunnyService->uploadBunnyVideo($binaryVideo, $videoId);

        if ($uploadVideoRes["success"] == true && $uploadVideoRes["statusCode"]  == 200) {

            $threadId = $this->data['threadId'];

            $thread = $app->em()->find('XF:Thread', $threadId);

            if ($thread->FirstPost) {

                $oldMessage = $thread->FirstPost["message"];

                $bunnyBBCode = "[fsbunny=" . $libarayId . "]" . $videoId . "[/fsbunny]";

                $newMessage = preg_replace("/\[fsbunny=\d+\]\[\/fsbunny\]/", $bunnyBBCode, $oldMessage);

                // $bunnyBBCode = "[fsbunny=" . $libarayId . "]" . $videoId . "[/fsbunny]";

                // $newMessage = $oldMessage . " [br]1[/br] " . $bunnyBBCode;

                $thread->FirstPost->fastUpdate('message', $newMessage);

                $thread->fastUpdate('is_uploaded', 1);

                $app->fs()->delete('data://BunnyIntegration/' . $this->data['bunnyVideo']);

                return $this->complete();
            }
        }
        //   }

        return $this->resume();
    }

    public function getStatusMessage()
    {
    }

    public function canCancel()
    {
        return true;
    }

    public function canTriggerByChoice()
    {
        return true;
    }
}
