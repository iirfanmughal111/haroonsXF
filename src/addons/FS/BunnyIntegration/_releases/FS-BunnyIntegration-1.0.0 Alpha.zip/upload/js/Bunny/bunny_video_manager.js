/** @param {jQuery} $ jQuery Object */
!(function ($, window, document) {
  "use strict";

  XF.BlockSubmit = XF.Click.newHandler({
    eventNameSpace: "BlockSubmit",

    options: {
      delay: 200,
    },

    loading: false,

    init: function () {},

    click: function (e) {
      e.preventDefault();

      this.loading = true;

      console.log(this.editor);

      var bunnyVideoId = $("[name=bunnyVidId]").val();
      var bunnyVideoLibrary = $("[name=bunnyLibId]").val();

      var bunnyBBCode = "[fsbunny=" + bunnyVideoLibrary + "][/fsbunny]";

      $(".fr-element p").append(bunnyBBCode);
    },
  });

  XF.BlockDelete = XF.Click.newHandler({
    eventNameSpace: "BlockDelete",

    options: {
      delay: 200,
    },

    loading: false,

    init: function () {},

    click: function (e) {
      e.preventDefault();

      this.loading = true;

      var bunnyVideoDelete = $("[name=bunnyVidExten]").val();

      var phraseUrl = XF.canonicalizeUrl("index.php?forums/0/delete-video");

      var formdata = new FormData();

      formdata.append("_xfToken", XF.config.csrf);
      formdata.append("videoName", bunnyVideoDelete);

      $.ajax({
        type: "POST",
        url: phraseUrl,
        data: formdata,
        contentType: false,
        processData: false,
        success: function (response) {
          $('input[name="bunny_video"]').val("");
          $("#setUploadedVideo").children().remove();
        },
      });
    //   $(".fr-element p").append(bunnyBBCode);
    },
  });
  XF.Element.register("insert-bunny", "XF.BlockSubmit");
  XF.Element.register("delete-bunny", "XF.BlockDelete");
})(jQuery, window, document);
