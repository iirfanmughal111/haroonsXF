XF.Element.extend("attachment-manager", {
  actionButtonClick: function (e) {
    e.preventDefault();

    var $target = $(e.currentTarget),
      action = $target.attr("data-action"),
      type = $target.attr("data-type"),
      $row = $target.closest(this.options.fileRow);

    switch (action) {
      case "thumbnail":
      case "full":
        this.insertAttachment($row, action, type);
        break;

      case "delete":
        this.deleteAttachment($row, type);
        break;

      case "cancel":
        this.cancelUpload($row);
        break;

      case "bunny":
        this.attachBunnyVideo($row, action, type);
        break;
    }
  },

  attachBunnyVideo: function ($row, action, type) {
    // alert("click to insert attachment");

    type = type;

    if (!this.editor) {
      return;
    }

    var thumb = $row.find(this.options.templateThumb).attr("src"),
      view = $row.find(this.options.templateView).attr("href");

    // XF.options.fs_bi_libraryId;

    // console.log(XF.options.fs_bi_libraryId);
    console.log(this.options.fs_bi_libraryId);
    var html,
      bbCode,
      params = {
        id: 330,
        img: thumb,
      };

    if (action == "bunny") {
      bbCode = "[ATTACH=full]" + 331 + "[/ATTACH]";

      // bbCode = "[br]1[/br] [fsbunny= {$thread['bunny_lib_id']}][/fsbunny]";

      // $newMessage = $post->message + " [br]1[/br] " + $bunnyBBCode;

      // if (type == "video") {
      //   html =
      //     '<span contenteditable="false" draggable="true" class="fr-video fr-dvi fr-draggable fr-deletable"><video data-xf-init="video-init" data-attachment="full:{{id}}" src="{{img}}" controls></video></span>';
      // }

      // var variable = JSON.parse("<?php XF::options()->fs_bi_libraryId ?>");

      // '[fs_word_highlight]' . $value . '[/fs_word_highlight]'

      if (type == "video") {
        html =
          '<span class="fr-video fr-dvi fr-draggable fr-deletable"><video data-xf-init="video-init" data-attachment="full:{{id}}" src="{{img}}" controls></video></span>';
        // '<span class="fr-video fr-dvi fr-draggable fr-deletable"><video data-xf-init="video-init" data-attachment="full:{{id}}" src="{{img}}" controls></video></span> [br]1[/br] [fsbunny= {$xf.options.fs_bi_libraryId}][/fsbunny]';
      }

      //   if (type == "video") {
      //     html = "[br]1[/br] [fsbunny= {$xf.options.fs_bi_libraryId}][/fsbunny]";
      //   }
      params.img = view;
    }

    html = Mustache.render(html, params);
    XF.insertIntoEditor(
      this.$target,
      html,
      bbCode,
      "[data-attachment-target=false]"
    );
  },
});
