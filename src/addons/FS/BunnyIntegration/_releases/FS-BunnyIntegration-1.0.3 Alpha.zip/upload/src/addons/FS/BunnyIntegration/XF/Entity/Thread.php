<?php

namespace FS\BunnyIntegration\XF\Entity;

use XF\Mvc\Entity\Structure;

class Thread extends XFCP_Thread
{

    // public static function getStructure(Structure $structure)
    // {
    //     $structure = parent::getStructure($structure);

    //     $structure->columns['bunny_lib_id'] =  ['type' => self::UINT, 'default' => 0];
    //     $structure->columns['bunny_vid_id'] =  ['type' => self::STR, 'default' => null];
    //     $structure->columns['is_uploaded'] =  ['type' => self::UINT, 'default' => 0];

    //     return $structure;
    // }

    // public function getVideoIsUploaded()
    // {
    //     $libraryId = $this->bunny_lib_id;
    //     $videoId = $this->bunny_vid_id;

    //     $bunnyService = \xf::app()->service('FS\BunnyIntegration\XF:BunnyServ');
    //     $res = $bunnyService->getBunnyVideo($libraryId, $videoId);

    //     return $res;
    // }

    // protected function _postDelete()
    // {
    //     if (($this->bunny_lib_id != 0) && ($this->bunny_vid_id != Null)) {
    //         $bunnyService = \xf::app()->service('FS\BunnyIntegration\XF:BunnyServ');
    //         $response = $bunnyService->delelteBunnyVideo($this->bunny_lib_id, $this->bunny_vid_id);
    //     }

    //     return parent::_postDelete();
    // }
}
