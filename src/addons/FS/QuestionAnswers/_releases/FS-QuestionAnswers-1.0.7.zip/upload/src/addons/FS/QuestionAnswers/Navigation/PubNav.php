<?php


namespace FS\QuestionAnswers\Navigation;

use XF\Admin\App;

class PubNav
{
    // public static function addNavigationItem(array &$extraTabs, $selectedTabId)
    // {
    //     $extraTabs['public_nav'] = [
    //         'title' => 'Public Navigation',
    //         'href' => XenForo_Link::buildPublicLink('your-route'),
    //         'position' => 'middle',
    //         'linksTemplate' => 'your_template',
    //         'selected' => ($selectedTabId == 'public_nav')
    //     ];
    // }


    public static function addNavigationItem()
    {

        return 'http://localhost/xenforo/index.php?forums/testing-question.11/';
    }
}
