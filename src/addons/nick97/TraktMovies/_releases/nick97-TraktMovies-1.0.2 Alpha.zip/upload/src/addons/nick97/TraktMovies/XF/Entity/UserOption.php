<?php

namespace nick97\TraktMovies\XF\Entity;

/**
 * COLUMNS
 * @property string $nick97_movies_trakt_watch_region
 */
class UserOption extends XFCP_UserOption
{
	//
}
